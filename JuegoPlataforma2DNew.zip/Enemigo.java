import java.awt.*;

public abstract class Enemigo extends Entidad {
    public Enemigo(int x, int y, int ancho, int alto) {
        super(x, y, ancho, alto);
    }
}
